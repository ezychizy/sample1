# setwd("Program/R")

greet <- function(name) {
  print(paste("Hello,", name, "!"))
}


